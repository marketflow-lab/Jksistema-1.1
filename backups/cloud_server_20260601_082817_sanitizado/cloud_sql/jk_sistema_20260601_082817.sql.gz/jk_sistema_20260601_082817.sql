--
-- PostgreSQL database dump
--

\restrict crWMfO1eIyuqD3kKWbohI9wrkZKjc86HZOXvPI6kRV1xkdcPsZA1CTUCIQpJUyE

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA public TO cloudsqlsuperuser;


--
-- PostgreSQL database dump complete
--

\unrestrict crWMfO1eIyuqD3kKWbohI9wrkZKjc86HZOXvPI6kRV1xkdcPsZA1CTUCIQpJUyE

